# Dick’s-A-Thon • NEON SNAKE — EPIC

Physical • Mental • **Gastrointestinal**. Now also **Digital**.
Collect burgers, fries, and shakes; dodge ketchup splats; become legend.

## Deploy (GitHub Pages)
1. New repo (e.g. `dicks-a-thon-neon-snake-epic`).
2. Upload everything in this folder (root: `index.html`, `src/`, `assets/`, `sw.js`, `manifest.webmanifest`).
3. Settings → Pages → Source: *Deploy from a branch* → Branch: `main` → Folder: `/ (root)` → Save.
4. Your link: `https://<username>.github.io/<repo>/`

## Controls
- **Mobile**: Swipe to steer • Tap ⏸ to pause • On‑screen D‑pad
- **Desktop**: Arrows/WASD • **Space** = pause • **M** = SFX • **N** = Music • **W** = Wrap walls

## Scoring
- 🍔 Burger: +10
- 🍟 Fries: +12
- 🥤 Shake: +20 & +2 length
- ⭐ Golden Fry: x2 score for 10s

> iOS Files preview isn’t a browser—publish or open in Safari/Chrome for taps & audio.

MIT License for the game code.
